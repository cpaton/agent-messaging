class A { 
 public: 
  A() {}
  
  void hello() 
    {}
}; 
