#include "imports_a.h"

class B : public A 
{ 
 public: 
  B() {};
  
  void bye() 
    {} ;
};

