open Swig
open Overload_copy

let f = new_Foo C_void 
let g = new_Foo f 
